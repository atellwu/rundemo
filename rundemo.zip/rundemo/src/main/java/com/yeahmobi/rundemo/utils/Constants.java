package com.yeahmobi.rundemo.utils;

public class Constants {

	public static final String CLASSPATH = "classpath";

	public static final String SRC = "src";

	public static final String POM = "pom.xml";

}