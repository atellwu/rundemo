#!/bin/bash
## $1 is app; $2 is pageid
cp /data/rundemo/appprojects/$1/resources/* /data/rundemo/javaprojects/$1/$2/bin/
