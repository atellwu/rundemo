#!/bin/bash
ping 127.0.0.1 
echo $! > pid
