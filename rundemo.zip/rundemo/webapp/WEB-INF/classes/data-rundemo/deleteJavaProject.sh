#!/bin/bash
rm -rf /data/rundemo/javaprojects/$1/$2
